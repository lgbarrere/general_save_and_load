#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fichier.h"
#include "donnees.h"
#include "constantes.h"
#include "erreur.h"


Rapport ouvrir_fichier(FILE **fichier, char *nomDeFichier, char *mode)
{
    if(nomDeFichier == NULL)
    {
        faire_un_rapport("Erreur : nom de fichier NULL.\n");
        return ERREUR;
    }

    if(mode == NULL)
    {
        faire_un_rapport("Erreur : mode NULL.\n");
        return ERREUR;
    }

    if(fichier != NULL)
        fermer_fichier(fichier);

    *fichier = fopen(nomDeFichier, mode);

    if(*fichier == NULL)
        return ECHEC;

    return SUCCES;
}


Rapport fermer_fichier(FILE **fichier)
{
    if(fclose(*fichier) != 0)
        return ECHEC;

    return SUCCES;
}


Rapport lire_ligne(char ligne[], int tailleMaxLigne, FILE *fichier)
{
    test_allocation(ligne);
    test_allocation(fichier);

    if(tailleMaxLigne < 1)
    {
        faire_un_rapport("Erreur : Impossible de lire une ligne d'au plus 0 caractere.");
        return ERREUR;
    }

    if(fgets(ligne, tailleMaxLigne, fichier) != NULL)
    {
        // on cherche le '\n' pour le retirer
        char *positionEntree = NULL;
        positionEntree = strchr(ligne, '\n');

        if(positionEntree != NULL)
            *positionEntree = '\0';

        return SUCCES;
    }

    return ECHEC;
}


Rapport ecrire_ligne(char *ligne, FILE *fichier)
{
    test_allocation(ligne);
    test_allocation(fichier);

    if(fputs(ligne, fichier) == EOF)
    {
        faire_un_rapport("Echec : Impossible d'ecrire dans un fichier.");
        return ECHEC;
    }

    return SUCCES;
}


void faire_un_rapport(char *message)
{
    test_allocation(message);

    char nomDeRapport[TAILLE_NOM_RAPPORT];
    int numeroDeRapport;
    FILE* fichier = NULL;

    sprintf(nomDeRapport, "rapports/rapport_%d.txt", MAX_RAPPORTS);

    // si on a trop de rapport, on les d�truit tous
    if(ouvrir_fichier(&fichier, nomDeRapport, "r") == SUCCES)
    {
        fermer_fichier(&fichier);

        for(numeroDeRapport = 1; numeroDeRapport <= MAX_RAPPORTS; numeroDeRapport++)
        {
            sprintf(nomDeRapport, "rapports/rapport_%d.txt", numeroDeRapport);
            remove(nomDeRapport);
        }
    }

    numeroDeRapport = 1;
    sprintf(nomDeRapport, "rapports/rapport_%d.txt", numeroDeRapport);

    // on essaie d'ouvrir tous les rapport, si c'est impossible, on cr�e ce dernier
    while(ouvrir_fichier(&fichier, nomDeRapport, "r") == SUCCES)
    {
        fermer_fichier(&fichier);
        numeroDeRapport++;
        sprintf(nomDeRapport, "rapports/rapport_%d.txt", numeroDeRapport);
    }

    // on ferme le pr�c�dent fichier, puis on g�n�re un fichier
    fermer_fichier(&fichier);
    ouvrir_fichier(&fichier, nomDeRapport, "a");
    ecrire_ligne(message, fichier);
    fermer_fichier(&fichier);
}


int taille_de_nombre(int nombre)
{
    int i = 0;

    // si nombre est n�gatif, il faut compter le signe
    if(nombre < 0)
        i++;

    // un nombre comptient au moins un chiffre, on compte donc une fois de plus
    do
    {
        nombre = nombre/10;
        i++;
    }
    while(nombre != 0);

    return i;
}



void sauvegarder(Donnees *sauvegarde, char *nomDeSauvegarde)
{
    test_allocation(nomDeSauvegarde);

    // on va sauvegarder dans un fichier nomm� "temporaire" pour ne pas �craser la sauvegarde
    FILE* fichierDeSauvegarde = NULL;
    char temporaire[] = "temporaire.txt";
    ouvrir_fichier(&fichierDeSauvegarde, temporaire, "w+");

    unsigned int i = 0, j = 0, k = 0, plusLongueLigne = 0;

    // on cherche le mot le plus long � sauvegarder pour l'allocation d'un chiffreur
    for(i = 0; i < sauvegarde->nombreDeLignes; i++)
    {
        k = 0;

        for(j = 0; j < sauvegarde->tailleLignes[i]; j++)
        {
            switch(sauvegarde->type[i])
            {
                case TYPE_INDEFINI:
                    faire_un_rapport("Erreur : Un type du tableau de donn�es n'est pas reconnu.");
                    exit(EXIT_FAILURE);
                    break;
                case TYPE_INT:
                    k = k + taille_de_nombre(sauvegarde->tableauDeDonnees[i][j].entier) + 1;
                    break;
                case TYPE_DOUBLE:
                    break;
                case TYPE_STRING:
                    k = k + strlen(sauvegarde->tableauDeDonnees[i][j].chaine) + 1;
                    break;
            }
        }

        if(plusLongueLigne < k)
            plusLongueLigne = k;
    }

    // on va supprimer le fichier de sauvegarde pr�c�dent, puis renommer "temporaire" pour qu'il devienne la sauvegarde
    fermer_fichier(&fichierDeSauvegarde);
    remove(nomDeSauvegarde);
    rename(temporaire, nomDeSauvegarde);
}


unsigned int max_ligne_fichier(char *nomDeFichier)
{
    test_allocation(nomDeFichier);

    unsigned int plusLongueLigne = 0;

    FILE *fichier = NULL;
    if(ouvrir_fichier(&fichier, nomDeFichier, "r") != SUCCES)
    {
        faire_un_rapport("Erreur : un fichier n'a pas pu �tre ouvert.");
        exit(EXIT_FAILURE);
    }

    char c = ' ';

    while(c != EOF)
    {
        unsigned int i = 0;

        while(c != '\n' && c != EOF)
        {
            c = fgetc(fichier);
            i++;
        }

        if(plusLongueLigne < i)
            plusLongueLigne = i;

        if(c != EOF)
            c = fgetc(fichier);
    }

    fermer_fichier(&fichier);

    // +2 permet de compter un '\0' et un �ventuel '\n'
    return plusLongueLigne+2;
}


unsigned int couper_espaces(char *chaine, char **debutDeMot, char **finDeMot)
{
    test_allocation(chaine);
    test_allocation(debutDeMot);
    test_allocation(finDeMot);

    unsigned int i = 0;

    // cette boucle sert � retirer les �ventuels espace en d�but de cha�ne
    while(chaine[i] == ' ' && chaine[i] != '\n' && chaine[i] != '\0' && chaine[i] != EOF)
        i++;

    *debutDeMot = chaine + i;

    // on continue le parcourt de la cha�ne avec i et on compte la taille � extraire avec tailleDuMot
    while(chaine[i] != ' ' && chaine[i] != '\n' && chaine[i] != '\0' && chaine[i] != EOF)
        i++;

    *finDeMot = chaine + i;

    // ne pas oublier le +1 pour compter le '\0'
    return *finDeMot + 1 - *debutDeMot;
}


void charger(Donnees *charge, char *nomDeFichier)
{
    test_allocation(nomDeFichier);
}
