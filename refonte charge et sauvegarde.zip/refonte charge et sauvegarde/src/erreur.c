#include <stdio.h>
#include <stdlib.h>

#include "erreur.h"
#include "fichier.h"


void test_allocation(void *pointeur)
{
    // un pointeur NULL g�n�re un rapport d'erreur avec son nom
    if(pointeur == NULL)
    {
        faire_un_rapport("Erreur : Mauvaise allocation.");
        exit(EXIT_FAILURE);
    }
}
