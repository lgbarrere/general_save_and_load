#include <stdio.h>
#include <stdlib.h>

#include "erreur.h"
#include "fichier.h"


void test_allocation(void *pointeur)
{
    // un pointeur NULL g�n�re un rapport d'erreur avec son nom
    if(pointeur == NULL)
    {
        faire_un_rapport("Erreur : Mauvaise allocation.");
        exit(EXIT_FAILURE);
    }
}


void test_bornes(int variable, int minimum, int maximum)
{
    if(variable < minimum || variable > maximum)
    {
        faire_un_rapport("Erreur : Les bornes d'une variable ne sont pas respect�es.");
        exit(EXIT_FAILURE);
    }
}


bool verifier_NULL(void *pointeur)
{
    if(pointeur == NULL)
        return true;

    return false;
}


bool verifier_bornes(int variable, int minimum, int maximum)
{
    if(variable < minimum || variable > maximum)
        return false;

    return true;
}
