﻿#include <stdio.h>
#include <stdlib.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>

#include <string.h>

#include "constantes.h"
#include "interface.h"
#include "fichier.h"
#include "erreur.h"
#include "donnees.h"
#include "chiffrement.h"

int main(int argc, char *argv[])
{
    if(argc > 1)
        printf("./%s\n", argv[0]);

    /** INITIALISATIONS **/
    SDL_Window *ecran = NULL; // ecran d'affichage
    SDL_Renderer *renderer = NULL; // zone de dessin
    SDL_Texture *imageDeFond = NULL; // image
    TTF_Font *police = NULL; // police
    SDL_Color texteColor = {0, 0, 0, 255}; // couleur de texte
    SDL_Texture *textureTexte = NULL; // texte
    SDL_Rect zoneTexte; // zone dans laquelle afficher le texte
    char continuer = 1; // indicateur booléen pour la boucle principale

    /** DEBUT CHARGEMENT/SAUVEGARDE **/

    unsigned int i = 0;
    const unsigned int nombreDeLignes = 3, nombreDeMots = 5;
    unsigned int taillesLignes[100][nombreDeLignes];
    Type types[nombreDeLignes];
    unsigned int tailleMots[nombreDeMots];

    types[0] = TYPE_INT;
    types[1] = TYPE_STRING;
    types[2] = TYPE_DOUBLE;

    tailleMots[0] = 19;
    tailleMots[1] = 10;
    tailleMots[2] = 10;
    tailleMots[3] = 5;
    tailleMots[4] = 9;

    for(i = 0; i < 100; i++)
    {
        taillesLignes[i][0] = 3;
        taillesLignes[i][1] = nombreDeMots;
        taillesLignes[i][2] = 2;
    }

    Donnees **d[100], **d2[100];

    for(i = 0; i < 100; i++)
    {
        d[i] = creer_donnees(nombreDeLignes, taillesLignes[i], types, tailleMots);
        d2[i] = creer_donnees(nombreDeLignes, taillesLignes[i], types, tailleMots);
    }

    d[0][0][0].entier = 4;
    d[0][0][1].entier = 0;
    d[0][0][2].entier = 1;


    d[0][1][0].mot = "Test de sauvegarde";
    d[0][1][1].mot = "objets :";
    d[0][1][2].mot = "boomerang";
    d[0][1][3].mot = "épée";
    d[0][1][4].mot = "bouclier";

    d[0][2][0].reel = 0.0;
    d[0][2][1].reel = 8.34;

    sauvegarder(d[0], "rapports/test_sauvegarde.txt", nombreDeLignes, taillesLignes[0], types, tailleMots);
    charger(d2[0], "rapports/test_sauvegarde.txt", nombreDeLignes, taillesLignes[0], types, tailleMots);
    afficher_donnees(d2[0], nombreDeLignes, taillesLignes[0], types);

    for(i = 0; i < 100; i++)
    {
        liberer_donnees(d[i], nombreDeLignes, taillesLignes[0], types);
        liberer_donnees(d2[i], nombreDeLignes, taillesLignes[0], types);
    }

    /** FIN CHARGEMENT/SAUVEGARDE **/

    /** DEMARRAGE DE LA SDL2 **/
    if(SDL_Init(SDL_INIT_VIDEO) == -1)
    {
        faire_un_rapport("Erreur lors de l'initialisation de la SDL.");
        return EXIT_FAILURE;
    }

    if(IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG)
    {
        faire_un_rapport("Erreur lors de l'initialisation de la SDL_image.");
        return EXIT_FAILURE;
    }

    if(TTF_Init() == -1)
    {
        faire_un_rapport("Erreur lors de l'initialisation de la SDL_TTF.");
        return EXIT_FAILURE;
    }

    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1)
    {
        faire_un_rapport("Erreur lors de l'initialisation de la SDL_mixer.");
        return EXIT_FAILURE;
    }

    /** MENU PRINCIPAL **/
    // on crée une fenêtre avec titre, icone et fond
    ecran = fenetre(TITRE, ICONE);
    renderer = rendu(ecran);
    imageDeFond = texture(renderer, FOND);

    // on charge la police
    police = TTF_OpenFont(CHEMIN_TEXTE, TAILLE_TEXTE);

    // génère la texture du texte et sa taille (en rectangle)
    textureTexte = texte(renderer, police, "Zone de Texte Accentuée", texteColor);
    SDL_QueryTexture(textureTexte, NULL, NULL, &zoneTexte.w, &zoneTexte.h);

    // positionnement du texte au centre de l'écran
    zoneTexte.x = LARGEUR_FENETRE/2 - zoneTexte.w/2;
    zoneTexte.y = HAUTEUR_FENETRE/2 - zoneTexte.h;

    /** EVENEMENTS **/
    SDL_Event event;

    while(continuer == 1)
    {
        SDL_WaitEvent(&event);

        // dessine les textures
        SDL_RenderCopy(renderer, imageDeFond, NULL, NULL);
        SDL_RenderCopy(renderer, textureTexte, NULL, &zoneTexte);
        // met à jour l'écran
        SDL_RenderPresent(renderer);

        switch(event.type)
        {
            // on arrête si l'utilisateur clique sur la croix
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    // on arrête si l'utilisateur appuie sur la touche "échap"
                    case SDLK_ESCAPE:
                        continuer = 0;
                        break;
                }
        }

        // efface le renderer
        SDL_RenderClear(renderer);
    }

    /** LIBERATIONS **/
    SDL_DestroyWindow(ecran);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyTexture(imageDeFond);
    SDL_DestroyTexture(textureTexte);
    TTF_CloseFont(police);

    Mix_CloseAudio();
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();

    return EXIT_SUCCESS;
}
