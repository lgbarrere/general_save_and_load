﻿#include <stdio.h>
#include <stdlib.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

#include "interface.h"
#include "constantes.h"
#include "erreur.h"


SDL_Window *fenetre(char *titre, char *icone)
{
    test_allocation(titre);

    SDL_Window *ecran = NULL;

    // on crée de la fenêtre
    ecran = SDL_CreateWindow(titre, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, LARGEUR_FENETRE, HAUTEUR_FENETRE, SDL_WINDOW_SHOWN);
    test_allocation(ecran);

    // on génère une icone pour la nouvelle fenêtre (rien en cas d'erreur)
    if(icone != NULL)
        SDL_SetWindowIcon(ecran, IMG_Load(icone));

    return ecran;
}


SDL_Renderer *rendu(SDL_Window *ecran)
{
    test_allocation(ecran);

    SDL_Renderer *renderer = NULL;

    // on crée une zone d'affichage, un rendu
    renderer = SDL_CreateRenderer(ecran, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    test_allocation(renderer);

    return renderer;
}


SDL_Texture *texture(SDL_Renderer *renderer, char *nom_image)
{
    test_allocation(renderer);
    test_allocation(nom_image);

    SDL_Surface *image = NULL;
    SDL_Texture *texture = NULL;

    // on charge l'image
    image = IMG_Load(nom_image);
    test_allocation(image);

    // on "colle" l'image dans le renderer (zone de dessin)
    texture = SDL_CreateTextureFromSurface(renderer, image);
    test_allocation(texture);

    // on libère l'image chargée
    SDL_FreeSurface(image);

    return texture;
}


SDL_Texture *texte(SDL_Renderer *renderer, TTF_Font *police, char *chaine, SDL_Color texteColor)
{
    test_allocation(renderer);
    test_allocation(police);
    test_allocation(chaine);

    SDL_Surface *image = NULL;
    SDL_Texture *texture = NULL;

    // on crée une image du texte (en norme UTF-8)
    image = TTF_RenderUTF8_Blended(police, chaine, texteColor);
    test_allocation(image);

    // on "colle" l'image dans le renderer (zone de dessin)
    texture = SDL_CreateTextureFromSurface(renderer, image);
    test_allocation(texture);

    // on libère l'image chargée
    SDL_FreeSurface(image);

    return texture;
}
