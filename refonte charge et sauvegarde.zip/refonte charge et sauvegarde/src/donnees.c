#include <stdio.h>
#include <stdlib.h>

#include "donnees.h"
#include "erreur.h"
#include "fichier.h"


Donnees *creer_donnees(unsigned int *tailleLignes, unsigned int nombreDeLignes)
{
    test_allocation(tailleLignes);

    if(nombreDeLignes == 0)
    {
        faire_un_rapport("Erreur : le nombre de lignes du tableau de donn�es ne peut pas �tre nul.");
        exit(EXIT_FAILURE);
    }

    unsigned int i = 0, j = 0;

    Donnees *donnees = malloc(sizeof(Donnees));
    test_allocation(donnees);

    donnees->tailleLignes = tailleLignes;
    donnees->nombreDeLignes = nombreDeLignes;
    donnees->type = malloc(nombreDeLignes*sizeof(Types *));
    test_allocation(donnees->type);
    donnees->tableauDeDonnees = malloc(nombreDeLignes*sizeof(Contenu *));
    test_allocation(donnees->tableauDeDonnees);

    for(i = 0; i < nombreDeLignes; i++)
    {
        donnees->type[i] = TYPE_INDEFINI;

        donnees->tableauDeDonnees[i] = malloc(tailleLignes[i]*sizeof(Contenu));
        test_allocation(donnees->tableauDeDonnees[i]);

        for(j = 0; j < tailleLignes[i]; j++)
            donnees->tableauDeDonnees[i][j].chaine = NULL;
    }

    return donnees;
}


void liberer_donnees(Donnees *donnees)
{
    if(donnees != NULL)
    {
        unsigned int i = 0, j = 0;

        if(donnees->tableauDeDonnees != NULL)
        {
            for(i = 0; i < donnees->nombreDeLignes; i++)
            {
                if(donnees->tableauDeDonnees[i] != NULL)
                {
                    for(j = 0; j < donnees->tailleLignes[i]; j++)
                    {
                        switch(donnees->type[i])
                        {
                            // si le type est ind�fini, �a peut �tre source de probl�me, alors on le signale
                            case TYPE_INDEFINI:
                                faire_un_rapport("Attention : un type de donn�e est ind�fini lors la lib�ration des donn�es.");
                                break;
                            case TYPE_INT:
                                break;
                            case TYPE_DOUBLE:
                                break;
                            case TYPE_STRING:
                                if(donnees->tableauDeDonnees[i][j].chaine != NULL)
                                    free(donnees->tableauDeDonnees[i][j].chaine);
                                break;
                        }
                    }
                }
            }

            free(donnees->tableauDeDonnees);
        }

        if(donnees->type != NULL)
            free(donnees->type);

        free(donnees);
    }
}


void afficher_donnees(Donnees *donnees)
{
    printf("nombreDeLignes :\n%d\n\n", donnees->nombreDeLignes);
    printf("tailleLignes :\n");

    unsigned int i = 0, j = 0;

    for(i = 0; i < donnees->nombreDeLignes; i++)
        printf("%d ", donnees->tailleLignes[i]);

    printf("\n\n");

    printf("type :\n");

    for(i = 0; i < donnees->nombreDeLignes; i++)
    {
        switch(donnees->type[i])
        {
            case TYPE_INDEFINI:
                printf("TYPE_INDEFINI ");
                break;
            case TYPE_INT:
                printf("TYPE_INT ");
                break;
            case TYPE_DOUBLE:
                break;
            case TYPE_STRING:
                printf("TYPE_STRING ");
                break;
        }
        printf("\n");
    }

    printf("\n");

    printf("tableauDeDonnees :\n");

    for(i = 0; i < donnees->nombreDeLignes; i++)
    {
        test_allocation(donnees->tableauDeDonnees[i]);

        for(j = 0; j < donnees->tailleLignes[i]; j++)
        {
            switch(donnees->type[i])
            {
                case TYPE_INDEFINI:
                    printf("ERREUR");
                    break;
                case TYPE_INT:
                    printf("%d ", donnees->tableauDeDonnees[i][j].entier);
                    break;
                case TYPE_DOUBLE:
                    break;
                case TYPE_STRING:
                    printf("%s ", donnees->tableauDeDonnees[i][j].chaine);
                    break;
            }
        }

        printf("\n");
    }

    printf("\n");
}
