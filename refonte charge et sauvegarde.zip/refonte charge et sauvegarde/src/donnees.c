#include <stdio.h>
#include <stdlib.h>

#include "donnees.h"
#include "erreur.h"
#include "fichier.h"


Donnees **creer_donnees(unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types, unsigned int *tailleMots)
{
    Donnees **donnees = malloc(nombreDeLignes*sizeof(Donnees *));
    test_allocation(donnees);

    for(unsigned int i = 0; i < nombreDeLignes; i++)
    {
        donnees[i] = malloc(tailleLignes[i]*sizeof(Donnees));
        test_allocation(donnees[i]);

        for(unsigned int j = 0; j < tailleLignes[i]; j++)
        {
            switch(types[i])
            {
                case TYPE_INT:
                    donnees[i][j].entier = 0;
                    break;
                case TYPE_DOUBLE:
                    donnees[i][j].entier = 0;
                    break;
                case TYPE_STRING:
                    donnees[i][j].mot = calloc((tailleMots[j]+1), sizeof(char));
                    test_allocation(donnees[i][j].mot);
                    break;
            }
        }
    }

    return donnees;
}


void liberer_donnees(Donnees **donnees, unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types)
{
    if(donnees != NULL)
    {
        for(unsigned int i = 0; i < nombreDeLignes; i++)
        {
            if(donnees[i] != NULL)
            {
                for(unsigned int j = 0; j < tailleLignes[i]; j++)
                {
                    switch(types[i])
                    {
                        case TYPE_STRING:
                            if(donnees[i][j].mot != NULL)
                                free(donnees[i][j].mot);
                            break;
                        default:
                            break;
                    }
                }

                free(donnees[i]);
            }
        }

        free(donnees);
    }
}


void afficher_donnees(Donnees **donnees, unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types)
{
    printf("nombreDeLignes :\n%d\n\n", nombreDeLignes);
    printf("tailleLignes :\n");

    unsigned int i = 0, j = 0;

    for(i = 0; i < nombreDeLignes; i++)
        printf("%d ", tailleLignes[i]);

    printf("\n\n");

    printf("type :\n");

    for(i = 0; i < nombreDeLignes; i++)
    {
        switch(types[i])
        {
            case TYPE_INT:
                printf("TYPE_INT ");
                break;
            case TYPE_DOUBLE:
                printf("TYPE_DOUBLE ");
                break;
            case TYPE_STRING:
                printf("TYPE_STRING ");
                break;
        }
    }

    printf("\n\n");

    printf("tableauDeDonnees :\n");

    for(i = 0; i < nombreDeLignes; i++)
    {
        for(j = 0; j < tailleLignes[i]; j++)
        {
            switch(types[i])
            {
                case TYPE_INT:
                    printf("%d ", donnees[i][j].entier);
                    break;
                case TYPE_DOUBLE:
                    printf("%f ", donnees[i][j].reel);
                    break;
                case TYPE_STRING:
                    printf("\"%s\" ", donnees[i][j].mot);
                    break;
            }
        }

        printf("\n");
    }

    printf("\n");
}
