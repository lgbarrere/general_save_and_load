#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "chiffrement.h"


Chiffreur *allouer_chiffreur(unsigned int tailleMessage)
{
    Chiffreur *chiffreur = NULL;

    if(tailleMessage != 0)
    {
        chiffreur = malloc(tailleMessage*sizeof(Chiffreur));
        if(chiffreur == NULL)
        {
            fprintf(stderr, "Erreur : Mauvaise allocation.\n");
            exit(EXIT_FAILURE);
        }

        chiffreur->message = malloc(tailleMessage*sizeof(char));
        if(chiffreur->message == NULL)
        {
            fprintf(stderr, "Erreur : Mauvaise allocation.\n");
            exit(EXIT_FAILURE);
        }

        chiffreur->code = malloc((2*tailleMessage-1)*sizeof(char));
        if(chiffreur->code == NULL)
        {
            fprintf(stderr, "Erreur : Mauvaise allocation.\n");
            exit(EXIT_FAILURE);
        }
    }

    return chiffreur;
}


void liberer_chiffreur(Chiffreur *chiffreur)
{
    if(chiffreur != NULL)
    {
        if(chiffreur->message != NULL)
            free(chiffreur->message);

        if(chiffreur->code != NULL)
            free(chiffreur->code);

        free(chiffreur);
    }
}


int puissance(int nombre, int exposant)
{
    int i, stock = 1;

    for(i = 0; i < exposant; i++)
        stock = stock*nombre;

    return stock;
}


void chiffrer(Chiffreur *chiffreur)
{
    int i;

    /** CODE A REVOIR **/
    for(i = 0; i < chiffreur->tailleMessage; i++)
    {
        chiffreur->code[i] = chiffreur->message[i+i/3]%puissance(10, 3-(i%3)) + chiffreur->message[i+i/3+1]/puissance(10, 2-(i%3));

        if(i == chiffreur->tailleMessage-1)
            chiffreur->code[i] = chiffreur->message[i+i/3] * puissance(10, i/3+1);
    }

    chiffreur->code[(chiffreur->tailleMessage+1)*3/4] = '\0';
}


void dechiffrer(Chiffreur *chiffreur)
{
    int i;

    /** CODE A REVOIR **/
    for(i = 0; i < chiffreur->tailleMessage; i++)
    {
        chiffreur->message[i] = chiffreur->code[i+i/3]%puissance(10, 3-(i%3));
        chiffreur->message[i] = chiffreur->code[i+i/3+1]/puissance(10, 2-(i%3));

        if(i == chiffreur->tailleMessage-1)
            chiffreur->code[i] = chiffreur->message[i+i/3] * puissance(10, i/3+1);
    }

    chiffreur->message[i/2] = '\0';
}
