﻿/**
    fichier : constantes.h
    ----------------
    auteur : Yaranzo
    rôle : définir toutes les constantes présentes dans les sous-fichier du projet
**/

#ifndef MAIN
#define MAIN

#define TITRE "Fenêtre SDL2 minimaliste"
#define ICONE "images/icone.png"
#define FOND "images/fond.png"

#define LARGEUR_FENETRE 640
#define HAUTEUR_FENETRE 480

#define TAILLE_TEXTE 32
#define CHEMIN_TEXTE "texte/font.ttf"


#endif
