/**
    fichier : erreur.h
    ---------------------
    auteur : Yaranzo
    r�le : traiter les cas d'erreur proprement
**/

#ifndef DEF_ERREUR
#define DEF_ERREUR

#include <stdbool.h>


typedef enum
{
    SUCCES = 0, // une fonction s'est d�roul�e int�gralement
    ECHEC = 1,  // une fonction s'est d�roul�e partiellement
    ERREUR = -1 // une fonction s'est interrompue � cause d'une erreur
}Rapport;


/**
    r�le : quitter le programme avec rapport d'erreur si un pointeur est � NULL (mal allou�)
    retour : aucun
    > pointeur : un pointeur � tester
**/
void test_allocation(void *pointeur);


/**
    r�le : quitter le programme avec rapport d'erreur si une variable n'est pas comprise entre un minimum et un maximum (inclus)
    retour : aucun
    > variable : une variable � tester
    > minimum : la borne inf�rieure que doit avoir la variable
    > maximum : la borne sup�rieure que doit avoir la variable
**/
void test_bornes(int variable, int minimum, int maximum);


/**
    r�le : tester si un pointeur est NULL
    retour : true si le pointeur est NULL, sinon false
    > pointeur : un pointeur � tester
**/
bool verifier_NULL(void *pointeur);


/**
    r�le : tester si une variable est comprise entre un minimum et un maximum (inclus)
    retour : true si la variable respecte ses bornes, sinon false
    > variable : une variable � tester
    > minimum : la borne inf�rieure que doit avoir la variable
    > maximum : la borne sup�rieure que doit avoir la variable
**/
bool verifier_bornes(int variable, int minimum, int maximum);


#endif
