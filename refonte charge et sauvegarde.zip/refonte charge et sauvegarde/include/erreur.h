/**
    fichier : erreur.h
    ---------------------
    auteur : Yaranzo
    r�le : traiter les cas d'erreur proprement
**/

#ifndef DEF_ERREUR
#define DEF_ERREUR

#include <stdbool.h>


typedef enum
{
    SUCCES = 0, // une fonction s'est d�roul�e int�gralement
    ECHEC = 1,  // une fonction s'est d�roul�e partiellement
    ERREUR = -1 // une fonction s'est interrompue � cause d'une erreur
}Rapport;


/**
    r�le : quitter le programme avec rapport d'erreur si un pointeur est � NULL (mal allou�)
    retour : aucun
    > pointeur : un pointeur � tester
**/
void test_allocation(void *pointeur);


#endif
