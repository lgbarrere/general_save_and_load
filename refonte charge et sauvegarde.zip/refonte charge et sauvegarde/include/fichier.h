/**
    fichier : fichier.h
    ---------------------
    auteur : Yaranzo
    r�le : lire et �crire  dans un fichier de mani�re s�curis�e
**/

#ifndef DEF_FICHIER
#define DEF_FICHIER

#include "donnees.h"
#include "erreur.h"
#include "chiffrement.h"

#define MAX_RAPPORTS 99
#define TAILLE_NOM_RAPPORT 24


/**
    r�le : ouvrir proprement un fichier selon le mode d'ouverture voulu
    retour : SUCCES si le fichier est ouvert, sinon ECHEC
    > fichier : le pointeur qui recevra le fichier ouvert (si fichier a d�j� un contenu, il sera ferm� au pr�alable)
    > nomDeFichier : nom du fichier � ouvrir
    > mode : mode d'ouverture du fichier*

    *le mode comporte 6 types d'ouverture :
    > "r" LECTURE SEULE (lire dans un fichier d�j� pr�sent)
    > "w" ECRITURE SEULE (�crire dans un fichier, cr�� si absent)
    > "a" AJOUT EN FIN (�crire � la fin d'un fichier, cr�� si absent)
    > "r+" LIRE-ECRIRE (lire et �crire dans un fichier d�j� pr�sent)
    > "w+" ECRASER/LIRE-ECRIRE (�crase un fichier, puis permet de lire et �crire dedans)
    > "a+" LIRE-ECRIRE EN FIN (lire et �crire � la fin d'un fichier, cr�� si absent)
**/
Rapport ouvrir_fichier(FILE **fichier, char *nomDeFichier, char *mode);


/**
    r�le : fermer proprement un fichier
    retour : aucun
    > fichier : fichier � fermer
**/
Rapport fermer_fichier(FILE **fichier);


/**
    r�le : fonction s�curitaire pour vider le buffer apr�s une saisie
    retour : aucun
**/
void vider_buffer();


/**
    r�le : donner une ligne sous forme de cha�ne prise dans un fichier
    retour : SUCCES une ligne est r�cup�r�e, ECHEC si rien n'est fait, sinon ERREUR
    > ligne : la cha�ne � remplir avec la ligne lue dans le fichier
    > tailleMaxLigne : taille maximale � lire dans le fichier
    > fichier : fichier dans lequel r�cup�rer une ligne
**/
Rapport lire_ligne(char ligne[], int tailleMaxLigne, FILE *fichier);


/**
    r�le : �crire une cha�ne dans un fichier
    retour : SUCCES une ligne est �crite, ECHEC si rien n'est fait, sinon ERREUR
    > ligne : la cha�ne � �crire dans le fichier
    > fichier : fichier dans lequel �crire une ligne
**/
Rapport ecrire_ligne(char *ligne, FILE *fichier);


/**
    r�le : �crire un message dans un rapport g�n�r� dans la foul�e (si trop de rapports figurent, ils seront d�truits avant)
    retour : aucun
    > message : cha�ne � �crire dans le rapport d'erreur
**/
void faire_un_rapport(char *message);


int taille_de_nombre(int nombre);


/**
    r�le : enregistrer du contenu dans un fichier de sauvegarde
    retour : aucun
    > sauvegarde : contenu � sauver
    > nombreDeLignes : nombre de lignes � enregistrer
    > nomDeSauvegarde : nom du fichier dans lequel faire la sauvegarde
**/
void sauvegarder(Donnees *sauvegarde, char *nomDeSauvegarde);


unsigned int max_ligne_fichier(char *nomDeFichier);


unsigned int detecter_chaine(char *chaine, char **debutDeMot, char **finDeMot);


/**
    r�le : prendre tout le contenu d'un fichier de sauvegarde
    retour : aucun
    > charge : contenu � r�cup�rer
    > nomDeFichier : nom du fichier dans lequel pr�lever le contenu
    > type : sp�cification du type de chargement � faire (TYPE_INT ou TYPE_STRING)
**/
void charger(Donnees *charge, char *nomDeFichier);


#endif
