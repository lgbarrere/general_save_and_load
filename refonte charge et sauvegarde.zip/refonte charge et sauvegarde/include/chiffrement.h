/**
    fichier : chiffrement.h
    ----------------
    auteur : Yaranzo
    r�le : chiffrer une cha�ne de caract�re en code et d�chiffrer un code en cha�ne
**/

#ifndef DEF_CHIFFREMENT
#define DEF_CHIFFREMENT

#include <stdbool.h>


typedef struct
{
    int tailleMessage;
    char *message;
    char *code;
}Chiffreur;



/**
    r�le : allouer l'espace n�cessaire pour un message et un code (message chiffr�)
    retour : l'evironnement allou� pour le chiffreur
    > tailleMessage : le nombre de caract�res utilis�s pour faire un message ('\0' compris)
**/
Chiffreur *allouer_chiffreur(unsigned int tailleMessage);



/**
    r�le : lib�rer l'espace contenant un message et un code (message chiffr�)
    retour : aucun
    > chiffreur : l'environnement � lib�rer
**/
void liberer_chiffreur(Chiffreur *chiffreur);



/**
    r�le : chiffrer un message en code
    retour : aucun
    > message : message � chiffrer
    > code : message chiffr�
**/
void chiffrer(Chiffreur *chiffreur);



/**
    r�le : d�chiffrer un code en un message
    retour : aucun
    > code : code � d�chiffrer
    > message : code d�chiffr�
**/
void dechiffrer(Chiffreur *chiffreur);


#endif // DEF_CHIFFREMENT
