/**
    fichier : donnees.h
    ---------------------
    auteur : Yaranzo
    r�le : permettre de manipuler proprement les donn�es des fichiers de sauvegarde
**/

#ifndef DEF_DONNEES
#define DEF_DONNEES


typedef union
{
    char *chaine;
    int entier;
    double reel;
}Contenu;


typedef enum
{
    TYPE_INDEFINI, TYPE_INT, TYPE_DOUBLE, TYPE_STRING
}Types;


typedef struct
{
    unsigned int *tailleLignes; // taille en octet de chaque ligne
    unsigned int nombreDeLignes; // nombre de lignes � sauvegarder
    Types *type; // type des �l�mets par lignes � sauvegarder
    Contenu **tableauDeDonnees; // tableau des contenus � sauvegarder
}Donnees;


/**
    r�le : fournir un tableau de stockage de donn�es pour un fichier
    retour : le tableau de donn�es
    > tailleLignes : tableau indiquant le nombre de valeurs que peut contenir le tableau de donn�es � chaque ligne
    > nombreDeLignes : le nombre de ligne que peut contenir le tableau de donn�es
**/
Donnees *creer_donnees(unsigned int *tailleLignes, unsigned int nombreDeLignes);


/**
    r�le : lib�rer un tableau de donn�es et tous ses composants
    retour : aucun
    > donnees : le tableau de donn�es
**/
void liberer_donnees(Donnees *donnees);


/**
    r�le : afficher l'int�gralit� des donn�es dans la console
    retour : aucun
    > donnees : le tableau de donn�es
**/
void afficher_donnees(Donnees *donnees);


#endif
