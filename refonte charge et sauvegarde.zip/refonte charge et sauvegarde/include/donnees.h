/**
    fichier : donnees.h
    ---------------------
    auteur : Yaranzo
    r�le : permettre de manipuler proprement les donn�es des fichiers de sauvegarde
**/

#ifndef DEF_DONNEES
#define DEF_DONNEES


typedef enum
{
    TYPE_INT, TYPE_DOUBLE, TYPE_STRING // d�tection du type d'un �l�ment
}Type;


typedef union
{
    char *mot; // cha�ne � charger/sauver
    int entier; // entier � charger/sauver
    double reel; // r�el � charger/sauver
}Donnees;


/**
    r�le : fournir un tableau de stockage de donn�es pour un fichier
    retour : le tableau de donn�es (chaque ligne du tableau doit avoir un type diff�rent)
    > nombreDeLignes : le nombre de ligne que peut contenir le tableau de donn�es
    > tailleLignes : tableau indiquant le nombre d'�l�ments que peut contenir chaque ligne du tableau de donn�es
    > types : type des �l�ments de chaque ligne
    > tailleMots : taille des �ventuels mots de la charge/sauvegarde (doit �tre NULL si aucun mot)
**/
Donnees **creer_donnees(unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types, unsigned int *tailleMots);


/**
    r�le : lib�rer un tableau de donn�es et tous ses composants
    retour : aucun
    > donnees : le tableau de donn�es
    > nombreDeLignes : le nombre de ligne que peut contenir le tableau de donn�es
    > tailleLignes : tableau indiquant le nombre d'�l�ments que peut contenir chaque ligne du tableau de donn�es
    > types : type des �l�ments de chaque ligne
**/
void liberer_donnees(Donnees **donnees, unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types);


/**
    r�le : afficher l'int�gralit� des donn�es dans la console
    retour : aucun
    > donnees : le tableau de donn�es
    > nombreDeLignes : le nombre de ligne que peut contenir le tableau de donn�es
    > tailleLignes : tableau indiquant le nombre d'�l�ments que peut contenir chaque ligne du tableau de donn�es
    > types : type des �l�ments de chaque ligne
    > tailleMots : taille des �ventuels mots de la charge/sauvegarde (doit �tre NULL si aucun mot)
**/
void afficher_donnees(Donnees **donnees, unsigned int nombreDeLignes, unsigned int *tailleLignes, Type *types);


#endif
