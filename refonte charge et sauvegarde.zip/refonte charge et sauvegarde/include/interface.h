﻿/**
    fichier : interface.c
    ---------------------
    auteur : Yaranzo
    rôle : définir une fenêtre dans laquelle afficher des images et du texte
**/

#ifndef DEF_INTERFACE
#define DEF_INTERFACE


/**
    rôle : initialise une fenêtre vide
    retour : la fenêtre
    > titre : titre de la fenêtre
    > icone : chemin de l'icone (image) de la fenêtre (pas d'icone si c'est NULL)
**/
SDL_Window *fenetre(char *titre, char *icone);


/**
    rôle : prépare une zone de dessin sur tout l'écran
    retour : la zone de dessin sous forme de rendu
    > ecran : fenêtre dans laquelle dessiner
**/
SDL_Renderer *rendu(SDL_Window *ecran);


/**
    rôle : créer une texture à partir d'un nom d'image
    retour : la texture de l'image "collée" dans le renderer
    > renderer : zone de dessin dans laquelle poser la texture
    > nom_image : le nom de l'image à dessiner
**/
SDL_Texture *texture(SDL_Renderer *renderer, char *nom_image);


/**
    rôle : créer une texture à partir d'un texte
    retour : la texture du texte "collée" dans le renderer
    > renderer : zone de dessin dans laquelle poser la texture
    > police : police chargée avec une taille et un chemin d'accès
    > chaine : texte à transformer en texture affichable
    > texteColor : couleur du texte
**/
SDL_Texture *texte(SDL_Renderer *renderer, TTF_Font *police, char *chaine, SDL_Color texteColor);


#endif
